<?php
// Heading
$_['heading_title']      = 'OpenCart';

// Text
$_['text_profile']       = 'Ваш профиль';
$_['text_store']         = 'Магазины';
$_['text_help']          = 'Помощь';
$_['text_homepage']      = 'Сайт OpenCart';
$_['text_support']       = 'Форум поддержки';
$_['text_documentation'] = 'Документация';
$_['text_logout']        = 'Выход';