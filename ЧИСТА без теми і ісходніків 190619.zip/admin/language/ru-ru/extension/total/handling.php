<?php
// Heading
$_['heading_title']    = 'Плата за обработку заказа';

// Text
$_['text_total']       = 'Учитывать в заказе';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Настройки';

// Entry
$_['entry_total']      = 'Сумма заказа';
$_['entry_fee']        = 'Плата';
$_['entry_tax_class']  = 'Класс налога';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортировки';

// Help
$_['help_total']       = 'Лимит суммы заказа, для которой будет действовать плата ';

// Error
$_['error_permission'] = 'У Вас нет прав для управления данным модулем!';

