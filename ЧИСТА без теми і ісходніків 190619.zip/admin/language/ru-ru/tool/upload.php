<?php
// Heading
$_['heading_title']     = 'Внешние загрузки';

// Text
$_['text_success']      = 'Выполнено!';
$_['text_list']         = 'Внешние загрузки';

// Column
$_['column_name']       = 'Название Файла';
$_['column_filename']   = 'Имя Файла';
$_['column_date_added'] = 'Дата добавления';
$_['column_action']     = 'Действие';

// Entry
$_['entry_name']        = 'Название Файла';
$_['entry_filename']    = 'Имя Файла';
$_['entry_date_added'] 	= 'Дата добавления';

// Error
$_['error_permission']  = 'У Вас нет прав для управления данным модулем!';

