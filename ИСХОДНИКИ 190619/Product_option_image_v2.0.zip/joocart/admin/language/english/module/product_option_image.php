<?php
// Heading
$_['heading_title']       = 'Product Option Image';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified module product option image!';
$_['text_yes']   = 'Yes';
$_['text_no']   = 'No';

// Entry
$_['entry_enable']        = 'Enable:';
$_['entry_show_selected_image_in_cart']    = 'Show selected image in cart:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module product option image!';
?>