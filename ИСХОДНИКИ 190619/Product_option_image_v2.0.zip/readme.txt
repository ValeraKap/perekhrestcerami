Hi,

Thanks for you for being one of our valuable clients
If you find this extension useful,
Rates and comments will help us to bring you more updates with new features

--
WeDoWeb team
WeDoWeb.com.au | contact@wedoweb.com.au

ABOUT:
=========
 * @version 2
 * @author WeDoWeb.com.au | contact@wedoweb.com.au
 * @copyright (c) 2015

This extension allows admin to assign an unique image for each option value per product.
When the option is selected on front-end, main product image will be swapped with the corresponding option image.

FEATURES:
==================
This extension enhances your OpenCart store with the ability to:
- Assign different image for each option value per product
- When an option is selected, the main image will be swapped with that option's image
- Display selected option's image in Cart
- Support Select, Radio, Image type Options
- Support Color type Option (require Product Color Option extension - v1.4.2 or later)
- Can have multiple options with image per product

COMPATIBILITY:
==================
- OpenCart 2, OpenCart 1.5.1.3 and above
- JooCart, MijoShop
- Product Color Option v1.4.2 and later (http://www.opencart.com/index.php?route=extension/extension/info&extension_id=6907)
- Product Block Option http://www.opencart.com/index.php?route=extension/extension/info&extension_id=10910
- Product Image Option DropDown http://www.opencart.com/index.php?route=extension/extension/info&extension_id=7176
- Many zoom scripts: ColorBox, ElevateZoom, CloudZoom, LightBox, jQueryZoom, zoomLens, MagicZoom...
- Dependent Options extension
- Compatible with most themes
PLUS
Customising the mod to work with your theme (custom or not) is provided at no extra cost
Just drop an email to contact@wedoweb.com.au for any questions or supports.

DEMO:
==================
Default
http://wedoweb.com.au/picw/index.php?route=product/product&path=62&product_id=67

Combined with Product Color Option
http://wedoweb.com.au/picw/index.php?route=product/product&path=62&product_id=68

Admin
http://wedoweb.com.au/picw/admin (demo/demo)

HOW TO INSTALL:
==================
- If you haven't, install VqMod on your OpenCart store, the latest version can be found on http://vqmod.com
- Make sure VqMod has been installed completely and is running by browsing to YOUR_SITE/vqmod/install. It must displays VQMOD ALREADY INSTALLED!

- Upload admin, and vqmod folders to your OpenCart store directory (no core file will be overwritten)
- If you have Dependent Options installed, also upload catalog folder under extra\dependent options compatibility.
IMPORTANT NOTE: if you reinstall or update Dependent Options later, you will need to reupload this folder

- From Admin Panel, go to Extensions/Modules, and choose to install Product Option Image 

HOW TO USE:
==================
Note:
Option Images can be set in either Option form or Product form or both.
- Option Image set in Option form (OI-O) will be used for ALL products with that option.
- Option Image set in Product form (OI-P) will be applied for that product ONLY.
- If both are set, OI-P will be used.
With Image-type Options, both can be used as the same time: OI-O will be shown as thumbnail, OI-P will be switched with the product's image when the option is selected.

+ Options:
- Create new Options or update existing ones
- Option type MUST be Select, Radio, Image or Color type
- Add option values and assign image to each value.
Images are OPTIONAL except for Image-type Options.

+ Products:
- Add a new product or edit an existing one
- Add Select, Radio, Image or Color type Options with values
- Assign image for each value.
Images are OPTIONAL, there's no need to set image for every value.
An option value without image when selected will not change the product's image.
- Make sure all option value have a positive quantity or they won't appear on the site.

CHANGELOG:
==================
v2.0.0 (26/12/2014)
- compatible with OpenCart 2
- compatible with more themes: Bt Sneaker, Venice

v1.9.0 (04/05/2014)
- compatible with more zoom scripts: zoomLens, MagicZoom, jQueryZoom
- compatible with more themes: Journal, Pet Store
- compatible with new version of MijoShop

v1.8.0 (19/11/2013)
- make compatible with Lightbox
- make compatible with more themes
- fix bug no_image.jpg is displayed when an option with no image is selected

v1.7.0 (20/10/2013)
- Make compatible with more themes: Madame, SandalStore etc
- Now support Image Options

v1.6.1 (28/9/2013)
- Make compatible with CloudZoom
- Fix bugs

v1.6 (22/9/2013)
- Make compatible with ColorBox - the popup when you click on the product's main image - now will display the selected Option Image
- Make compatible with elevateZoom script

v1.5.1 (17/9/2013)
- Fix bugs

v1.5 (15/9/2013)
- JooCart compatible
- Dependent Options compatible

v1.4.2 (01/09/2013)
- Refine code
- Fix bugs show option image in cart not working (OpenCart 1.5.6 only)
- If an option value with no image set is selected, keep the previous option image instead of reverting back to product's main image

v1.4.1 (28/08/2013)
- Make compatible with OpenCart 1.5.1.3

v1.4 (24/08/2013)
- Make compatible with Optronics theme
- Fix minor bugs

v1.3 (12/08/2013)
- Update code to be compatible with more PHP versions and other extensions

v1.2 (09/08/2013)
- Fix bugs

v1.1 (06/08/2013)
- Fix bugs

v1.0 (27/7/2013)
- Initial releases