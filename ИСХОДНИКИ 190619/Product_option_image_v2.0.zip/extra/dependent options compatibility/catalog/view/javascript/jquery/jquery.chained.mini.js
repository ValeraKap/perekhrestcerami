(function (a) {
    a.fn.chained = function (b, c) {
        return this.each(function () {
            var c = this;
            var d = a(c).clone();
            a(b).each(function () {
                a(this).bind("change", function () {
                    a(c).html(d.html());
                    var e = "";
                    a(b).each(function () {
                        e += "\\" + a(":selected", this).val()
                    });
                    e = e.substr(1);
                    var f = a(b).first();
                    var g = a(":selected", f).val();
                    a("option", c).each(function () {
                        if (!a(this).hasClass(e) && !a(this).hasClass(g) && a(this).val() !== "") {
                            a(this).remove()
                        }
                    });
                    if (1 == a("option", c).size() && a(c).val() === "") {
                        a(c).attr("disabled", "disabled")
                    } else {
                        a(c).removeAttr("disabled")
                    }
                    a(c).trigger("change");
                    if (typeof obUpdate == "function") {
                        a(':input[name^="option"]', c).change(function () {
                            obUpdate(a(this), useSwatch)
                        })
                    }
                    if (typeof updatePx == "function") {
                        a(':input[name^="option"]', c).change(function () {
                            updatePx()
                        })
                    }
                  
				    if (typeof poiChangeSelect == "function") {
						a(':input[name^="option"]', c).change(function()
						{
							poiChangeSelect(a(this));
						});
					}
                });
                if (!a("option:selected", this).length) {
                    a("option", this).first().attr("selected", "selected")
                }
                a(this).trigger("change")
            })
        })
    };
    a.fn.chainedTo = a.fn.chained
})(jQuery)