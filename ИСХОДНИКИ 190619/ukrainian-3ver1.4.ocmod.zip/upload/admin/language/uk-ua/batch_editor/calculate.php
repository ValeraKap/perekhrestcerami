<?php
//$_[''] = '';

// Calculate
$_['ext_equal_number'] = '= число';
$_['ext_plus_number'] = 'поточне значення + число';
$_['ext_minus_number'] = 'поточне значення - число';
$_['ext_multiply_number'] = 'поточне значення * число';
$_['ext_divide_number'] = 'поточне значення / число';
$_['ext_plus_percent'] = 'поточне значення + відсоток';
$_['ext_minus_percent'] = 'поточне значення - відсоток';

$_['ext_price_plus_number'] = 'ціна товару + число';
$_['ext_price_minus_number'] = 'ціна товару - число';
$_['ext_price_multiply_number'] = 'ціна товару * число';
$_['ext_price_divide_number'] = 'ціна товару / число';
$_['ext_price_plus_percent'] = 'ціна товару + відсоток';
$_['ext_price_minus_percent'] = 'ціна товару - відсоток';
?>