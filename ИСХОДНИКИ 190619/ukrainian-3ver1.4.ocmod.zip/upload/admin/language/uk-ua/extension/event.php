<?php
// Heading
$_['heading_title'] = 'Події';

// Text
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_list'] = 'Події';
$_['text_event'] = 'Події змінюють стандартну функціональність вашого магазину. Якщо у вас виникли проблеми, ви можете відключити або включити події тут.';

// Column
$_['column_code'] = 'Код';
$_['column_trigger'] = 'Тригер';
$_['column_action'] = 'Дія';
$_['column_status'] = 'Статус';
$_['column_date_added'] = 'Додано';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для зміни налаштувань!';