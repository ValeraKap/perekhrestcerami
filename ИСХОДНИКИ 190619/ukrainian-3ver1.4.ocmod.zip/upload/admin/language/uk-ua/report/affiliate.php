<?php
// Heading
$_['heading_title'] = 'Звіт по комісіям партнерської програми';

// Text
$_['text_list'] = 'Звіт по комісіям партнерської програми';

// Column
$_['column_affiliate'] = 'Ім&#39;я партнера';
$_['column_email'] = 'E-Mail';
$_['column_status'] = 'Статус';
$_['column_commission'] = 'Комісія';
$_['column_orders'] = 'Кількість замовлень';
$_['column_total'] = 'Разом';
$_['column_action'] = 'Дія';

// Entry
$_['entry_date_start'] = 'Дата';
$_['entry_date_end'] = 'Дата закінчення';