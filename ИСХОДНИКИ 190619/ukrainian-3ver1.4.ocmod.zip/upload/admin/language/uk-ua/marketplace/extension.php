<?php
// Heading
$_['heading_title'] = 'Модулі/Додатки';

// Text
$_['text_success']  = 'Успіх: Ви змінили модуля!';
$_['text_list']     = 'Список розширень';
$_['text_type']     = 'Виберіть тип модуля';
$_['text_filter']   = 'Фільтр';