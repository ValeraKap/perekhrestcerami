<?php
// Text
$_['text_subject']      = '%s - Замовлення %s';
$_['text_received']     = 'Ви отримали замовлення.';
$_['text_order_id']     = 'ID Замовлення:';
$_['text_date_added']   = 'Дата створення';
$_['text_order_status'] = 'Статус замовлення:';
$_['text_product']      = 'Товари';
$_['text_total']        = 'Сума';
$_['text_comment']      = 'Коментар до ващого замовлення:';
