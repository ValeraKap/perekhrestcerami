<?php
// Heading
$_['heading_title'] = 'Файли для скачування';


// Text
$_['text_account'] = 'Особистий Кабінет';
$_['text_downloads'] = 'Файли для скачування';
$_['text_empty'] = 'У Вас немає замовлень з файлами для скачування!';

// Column
$_['column_order_id'] = '№ Замовлення';
$_['column_name'] = 'Назва';
$_['column_size'] = 'Розмір';
$_['column_date_added'] = 'Дата додавання';