<?php
// Текст
$_['text_title'] = 'Картка Віза та Мастеркард (через MoneyBookers)';