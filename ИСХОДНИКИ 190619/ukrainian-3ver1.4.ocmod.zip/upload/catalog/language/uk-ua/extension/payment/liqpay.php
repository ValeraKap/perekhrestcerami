<?php
// Text
$_['text_title'] = 'Карта Visa і MasterCard (LiqPay)';

