<?php
// Text
$_['text_success'] = 'API сесія успішно запущена!';

// Error
$_['error_key'] = 'УВАГА: Не коректний API Key!';
$_['error_ip'] = 'УВАГА: Ваш IP %s не знайдено у списку доступу до API!';